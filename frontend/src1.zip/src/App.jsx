import CoreScene from "./scenes/CoreScene";
import HUD from "./components/hud/HUD";
import BootScreen from "./components/boot/BootScreen";
import HUDOverlay from "./components/overlays/HUDOverlay";

function App() {
  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        background: "#02040A",
        position: "relative",
      }}
    >
      <CoreScene />

      <HUDOverlay />

      <HUD />

      <BootScreen />
    </div>
  );
}

export default App;