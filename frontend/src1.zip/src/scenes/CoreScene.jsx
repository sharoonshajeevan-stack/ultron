import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stars } from "@react-three/drei";
import { useRef } from "react";
import StarSphere from "../components/space/StarSphere";
import CoreGroup from "../components/ai/CoreGroup";
import BloomEffects from "../components/effects/BloomEffects";
import NearStars from "../components/space/NearStars";

function CameraController() {

  const controls = useRef();

  return (
    <OrbitControls

      ref={controls}

      enablePan={false}
      enableRotate={true}
      enableZoom={true}

      minDistance={1.5}
      maxDistance={80}

      minPolarAngle={Math.PI / 2.4}
      maxPolarAngle={Math.PI / 1.6}

    />
  );
}



export default function CoreScene() {

  return (

    <Canvas

      camera={{
        position:[0,0,6],
        fov:45,
      }}

      style={{
        width:"100%",
        height:"100%",
      }}

    >


      <color
        attach="background"
        args={["#000000"]}
      />



      {/* Deep Space Lighting */}

      <ambientLight intensity={0.25}/>


      <pointLight
        position={[0,0,3]}
        intensity={2}
        color="#55CCFF"
      />



      {/* ULTRON CORE */}

      <CoreGroup />

      <NearStars />


      <StarSphere />



      {/* Galaxy Universe */}

      <Stars

        radius={800}

        depth={500}

        count={30000}

        factor={12}

        saturation={0}

        fade={false}

        speed={0.15}

      />



      {/* Extra distant stars layer */}

      <Stars

        radius={1500}

        depth={900}

        count={15000}

        factor={6}

        saturation={0}

        fade={false}

        speed={0.05}

      />



      <BloomEffects />



      <CameraController />


    </Canvas>

  );
}