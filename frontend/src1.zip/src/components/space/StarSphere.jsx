import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { PointMaterial } from "@react-three/drei";

function generateStars() {
  const positions = [];

  let seed = 12345;

  function random() {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  }

  for (let i = 0; i < 8000; i++) {

    const theta = random() * Math.PI * 2;

    const phi = Math.acos(
      random() * 2 - 1
    );

    const radius = 250 + random() * 500;

    positions.push(
      Math.sin(phi) * Math.cos(theta) * radius,
      Math.sin(phi) * Math.sin(theta) * radius,
      Math.cos(phi) * radius
    );
  }

  return new Float32Array(positions);
}

const stars = generateStars();

export default function StarSphere() {

  const ref = useRef();

  useFrame(() => {
    if (!ref.current) return;

    ref.current.rotation.y += 0.00015;
    ref.current.rotation.x += 0.00005;
  });

  return (
    <points ref={ref}>

      <bufferGeometry>

        <bufferAttribute
          attach="attributes-position"
          array={stars}
          count={stars.length / 3}
          itemSize={3}
        />

      </bufferGeometry>

      <PointMaterial
        transparent
        color="#5da9ff"
        size={1.2}
        sizeAttenuation
        depthWrite={false}
      />

    </points>
  );
}