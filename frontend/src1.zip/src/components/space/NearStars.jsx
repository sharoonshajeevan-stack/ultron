import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { PointMaterial } from "@react-three/drei";


function createNearStars() {

  const positions = [];

  let seed = 9999;

  function random() {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  }


  for (let i = 0; i < 2500; i++) {

    positions.push(

      (random() - 0.5) * 80,

      (random() - 0.5) * 80,

      (random() - 0.5) * 80

    );

  }


  return new Float32Array(positions);

}


const stars = createNearStars();



export default function NearStars() {

  const ref = useRef();


  useFrame(() => {

    if(ref.current){

      ref.current.rotation.y += 0.0008;

      ref.current.rotation.x += 0.0003;

    }

  });



  return (

    <points ref={ref}>

      <bufferGeometry>

        <bufferAttribute

          attach="attributes-position"

          array={stars}

          count={stars.length / 3}

          itemSize={3}

        />

      </bufferGeometry>


      <PointMaterial

        color="#8bc7ff"

        size={0.8}

        transparent

        opacity={0.8}

        depthWrite={false}

      />

    </points>

  );

}