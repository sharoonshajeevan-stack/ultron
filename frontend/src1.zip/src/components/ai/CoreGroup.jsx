import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";

import OrbitParticles from "./OrbitParticles";
import AI_Core from "./AI_Core";
import EnergyRings from "./EnergyRings";
import HaloSystem from "./HaloSystem";
import ParticleCore from "./ParticleCore";


export default function CoreGroup() {

  const groupRef = useRef();
  const { camera } = useThree();


  useFrame(() => {

    if (!groupRef.current) return;


    const distance = camera.position.length();



    // Core scale reaction
    // Keeps core visible while exploring universe

    const scale = Math.max(
      0.7,
      Math.min(1.8, 5 / distance)
    );


    groupRef.current.scale.lerp(
      {
        x: scale,
        y: scale,
        z: scale
      },
      0.05
    );



    // Floating hologram movement

    groupRef.current.position.y =
      Math.sin(performance.now() * 0.001) * 0.05;


  });



  return (

    <group ref={groupRef}>


      <OrbitParticles />

      <HaloSystem />

      <AI_Core />

      <EnergyRings />

      <ParticleCore />


    </group>

  );

}