import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

function Ring({
  radius,
  tube,
  speed,
  color,
  tilt = [Math.PI / 2, 0, 0],
  opacity = 0.8,
}) {
  const ring = useRef();

  useFrame(({ clock }) => {
    if (!ring.current) return;

    const t = clock.getElapsedTime();

    ring.current.rotation.z = t * speed;

    ring.current.rotation.x =
      tilt[0] + Math.sin(t * 0.4 * speed) * 0.02;
  });

  return (
    <mesh ref={ring} rotation={tilt}>
      <torusGeometry args={[radius, tube, 16, 256]} />

      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={3}
        transparent
        opacity={opacity}
      />
    </mesh>
  );
}

export default function EnergyRings() {
  return (
    <>
      <Ring
        radius={1.45}
        tube={0.012}
        speed={0.45}
        color="#4FC3FF"
        opacity={0.9}
      />

      <Ring
        radius={1.70}
        tube={0.010}
        speed={-0.30}
        color="#00AAFF"
        tilt={[1.15, 0.5, 0]}
        opacity={0.6}
      />

      <Ring
        radius={1.95}
        tube={0.008}
        speed={0.20}
        color="#7FE7FF"
        tilt={[0.8, -0.6, 0]}
        opacity={0.45}
      />
    </>
  );
}