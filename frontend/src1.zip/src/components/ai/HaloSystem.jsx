import HaloRing from "./HaloRing";

export default function HaloSystem() {
  return (
    <>
      <HaloRing
        radius={1.45}
        rotationSpeed={0.18}
        tilt={[0, 0, 0]}
        opacity={0.30}
      />

      <HaloRing
        radius={1.62}
        rotationSpeed={-0.26}
        tilt={[1.2, 0.4, 0]}
        opacity={0.20}
      />

      <HaloRing
        radius={1.82}
        rotationSpeed={0.12}
        tilt={[0.8, -0.6, 0]}
        opacity={0.15}
      />
    </>
  );
}