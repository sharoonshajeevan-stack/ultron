import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Points, PointMaterial } from "@react-three/drei";

export default function ParticleCore() {
  const points = useRef();

  const particles = useMemo(() => {
    const array = [];

    const count = 3000;
    const radius = 1;

    for (let i = 0; i < count; i++) {
      // Deterministic spherical distribution
      const theta = (i * 2.399963229728653) % (Math.PI * 2);
      const v = (i + 0.5) / count;
      const phi = Math.acos(1 - 2 * v);

      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      array.push(x, y, z);
    }

    return new Float32Array(array);
  }, []);

  useFrame(({ clock }) => {
    if (!points.current) return;

    const t = clock.getElapsedTime();

    points.current.rotation.y = t * 0.08;
    points.current.rotation.x = Math.sin(t * 0.2) * 0.05;
  });

  return (
    <Points
      ref={points}
      positions={particles}
      stride={3}
      frustumCulled={false}
    >
      <PointMaterial
        transparent
        color="#66D8FF"
        size={0.015}
        sizeAttenuation
        depthWrite={false}
        opacity={0.9}
      />
    </Points>
  );
}