import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { AI_THEME } from "../../config/theme";

export default function Globe() {
  const globeRef = useRef();

  useFrame(({ clock }) => {
    if (!globeRef.current) return;

    const t = clock.getElapsedTime();

    globeRef.current.rotation.y = t * AI_THEME.core.rotationSpeed;

    globeRef.current.rotation.x = Math.sin(t * 0.25) * 0.03;

    globeRef.current.position.y =
      Math.sin(t) * AI_THEME.core.floatAmplitude;

    const scale = 1 + Math.sin(t * 2) * 0.01;
    globeRef.current.scale.set(scale, scale, scale);
  });

  return (
    <mesh ref={globeRef}>
      <sphereGeometry
        args={[AI_THEME.core.globeRadius, 64, 64]}
      />

      <meshPhysicalMaterial
        color={AI_THEME.colors.idle}
        transparent
        opacity={0.18}
        roughness={0}
        transmission={0.95}
        clearcoat={1}
        clearcoatRoughness={0}
        emissive={AI_THEME.colors.glow}
        emissiveIntensity={AI_THEME.core.emissiveIntensity}
      />
    </mesh>
  );
}