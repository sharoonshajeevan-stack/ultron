import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

export default function HaloRing({
  radius = 1.5,
  rotationSpeed = 0.25,
  tilt = [0, 0, 0],
  color = "#66D8FF",
  opacity = 0.25,
}) {
  const ring = useRef();

  useFrame(({ clock }) => {
    if (!ring.current) return;

    const t = clock.getElapsedTime();

    ring.current.rotation.z = t * rotationSpeed;
  });

  return (
    <mesh rotation={tilt} ref={ring}>
      <torusGeometry args={[radius, 0.012, 16, 220]} />

      <meshBasicMaterial
        color={color}
        transparent
        opacity={opacity}
      />
    </mesh>
  );
}