import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Torus } from "@react-three/drei";
import { AI_THEME } from "../../config/theme";


function GridRing({ rotation, radius, speed }) {
  const ref = useRef();

  useFrame(({ clock }) => {
    if (!ref.current) return;

    const t = clock.getElapsedTime();

    ref.current.rotation.z += speed;

    // subtle breathing hologram effect
    ref.current.material.opacity =
      0.25 + Math.sin(t * 2) * 0.08;
  });


  return (
    <Torus
      ref={ref}
      args={[radius, 0.004, 32, 256]}
      rotation={rotation}
    >
      <meshBasicMaterial
        color={AI_THEME.colors.idle}
        transparent
        opacity={0.35}
      />
    </Torus>
  );
}


export default function GlobeGrid() {

  return (
    <group>

      {/* Main holographic rings */}
      <GridRing
        rotation={[0,0,0]}
        radius={1.08}
        speed={0.002}
      />

      <GridRing
        rotation={[Math.PI/2,0,0]}
        radius={1.08}
        speed={-0.003}
      />

      <GridRing
        rotation={[0,Math.PI/2,0]}
        radius={1.08}
        speed={0.0015}
      />


      {/* Inner scanning rings */}
      <GridRing
        rotation={[0.5,0.8,0]}
        radius={0.82}
        speed={0.004}
      />

      <GridRing
        rotation={[-0.5,1.2,0]}
        radius={1.25}
        speed={-0.002}
      />

    </group>
  );
}