import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

export default function OrbitParticles() {
  const group = useRef();

  useFrame(({ clock }) => {
    if (!group.current) return;

    const t = clock.getElapsedTime();

    group.current.children.forEach((mesh, i) => {
      const radius = 1.4 + (i % 10) * 0.06;
      const speed = 0.25 + (i % 7) * 0.03;
      const angle = t * speed + i * 0.42;

      mesh.position.x = Math.cos(angle) * radius;
      mesh.position.z = Math.sin(angle) * radius;
      mesh.position.y = Math.sin(t * 2 + i * 0.3) * 0.15;

      const scale = 0.7 + Math.sin(t * 3 + i) * 0.15;
      mesh.scale.set(scale, scale, scale);
    });

    group.current.rotation.y = t * 0.05;
  });

  return (
    <group ref={group}>
      {Array.from({ length: 160 }, (_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.012, 8, 8]} />
          <meshBasicMaterial
            color="#66D8FF"
            transparent
            opacity={0.9}
          />
        </mesh>
      ))}
    </group>
  );
}