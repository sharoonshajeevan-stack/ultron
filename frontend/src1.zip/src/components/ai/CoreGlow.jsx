import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

export default function CoreGlow() {
  const glow1 = useRef();
  const glow2 = useRef();

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();

    if (glow1.current) {
      const s = 1 + Math.sin(t * 1.8) * 0.05;

      glow1.current.scale.set(s, s, s);

      glow1.current.material.opacity =
        0.16 + Math.sin(t * 2) * 0.04;
    }

    if (glow2.current) {
      const s = 1.25 + Math.sin(t * 1.4 + 1) * 0.08;

      glow2.current.scale.set(s, s, s);

      glow2.current.material.opacity =
        0.08 + Math.sin(t * 1.5) * 0.03;
    }
  });

  return (
    <>
      <mesh ref={glow2}>
        <sphereGeometry args={[1.05, 64, 64]} />

        <meshBasicMaterial
          color="#00AAFF"
          transparent
          opacity={0.08}
        />
      </mesh>

      <mesh ref={glow1}>
        <sphereGeometry args={[0.88, 64, 64]} />

        <meshBasicMaterial
          color="#66DDFF"
          transparent
          opacity={0.16}
        />
      </mesh>
    </>
  );
}