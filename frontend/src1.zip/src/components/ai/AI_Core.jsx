import { useRef } from "react";
import { useFrame } from "@react-three/fiber";

import { AI_THEME } from "../../config/theme";
import Globe from "./Globe";
import GlobeGrid from "./GlobeGrid";

export default function AI_Core() {
  const core = useRef();

  useFrame(({ clock }) => {
    if (!core.current) return;

    const t = clock.getElapsedTime();

    core.current.rotation.y = t * 0.35;
    core.current.rotation.x = Math.sin(t * 0.4) * 0.05;

    const pulse = 1 + Math.sin(t * 2) * 0.03;
    core.current.scale.set(pulse, pulse, pulse);
  });

  return (
    <group ref={core}>
      {/* Outer holographic shell */}
      <mesh>
        <sphereGeometry args={[AI_THEME.core.radius * 1.35, 64, 64]} />

        <meshStandardMaterial
          color={AI_THEME.colors.idle}
          emissive={AI_THEME.colors.glow}
          emissiveIntensity={AI_THEME.core.emissiveIntensity}
          wireframe
          transparent
          opacity={0.45}
        />
      </mesh>

      {/* Globe */}
      <Globe />

      {/* Grid */}
      <GlobeGrid />
    </group>
  );
}