import { EffectComposer, Bloom } from "@react-three/postprocessing";

export default function BloomEffects() {
  return (
    <EffectComposer multisampling={4}>
      <Bloom
        intensity={2.8}
        luminanceThreshold={0.15}
        luminanceSmoothing={0.95}
        mipmapBlur
      />
    </EffectComposer>
  );
}