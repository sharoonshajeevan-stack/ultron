import styles from "./HUD.module.css";

import TopBar from "./TopBar";
import LeftPanel from "./LeftPanel";
import RightPanel from "./RightPanel";
import BottomDock from "./BottomDock";

export default function HUD() {
  return (
    <div className={styles.hud}>
      <TopBar />

      <div className={styles.middle}>
        <LeftPanel />

        <div className={styles.center} />

        <RightPanel />
      </div>

      <BottomDock />
    </div>
  );
}