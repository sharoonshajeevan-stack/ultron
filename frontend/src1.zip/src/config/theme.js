export const AI_THEME = {
  colors: {
    idle: "#00aaff",
    thinking: "#ffffff",
    speaking: "#ff9900",
    alert: "#ff3333",
    background: "#000814",
    glow: "#008cff",
  },

  core: {
    radius: 1,
    globeRadius: 1.45,
    emissiveIntensity: 3,
    rotationSpeed: 0.08,
    floatAmplitude: 0.08,
  },

  rings: {
    color: "#00aaff",
    glow: "#008cff",
    sizes: [1.5, 1.8, 2.1],
  },

  particles: {
    count: 3000,
    size: 0.015,
  },
};